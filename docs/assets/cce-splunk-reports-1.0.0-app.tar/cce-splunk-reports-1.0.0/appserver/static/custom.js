require([
  'jquery',
  'splunkjs/mvc',
  'splunkjs/mvc/simplexml/ready!'
], function ($, mvc) {

  /* ---------------------------
   * 1) Inject Global Styles
   * --------------------------- */
  function injectGlobalStyles() {
    // Remove any old style so updates take effect
    $('#central-spacing-style, #central-spacing-style-v1').remove();

    const css = `
      /* === 1) Only the DASHBOARD title size === */
      .dashboard-header .dashboard-title,
      h1.dashboard-title {
        font-size: 32px !important;   /* change to 32px if you prefer */
        line-height: 1.2 !important;
        font-weight: 700 !important;
      }

      /* === 2) Space UNDER the dashboard header (for filters) === */
      .dashboard-header {
        margin-bottom: 20px !important;  /* tweak: 16–24px */
      }

      /* === 3) Filters on one line (NO extra top/bottom margin) === */
      .dashboard-form,
      .fieldset,
      .dashboard-form-row {
        display: flex !important;
        flex-wrap: wrap !important;
        gap: 16px !important;     /* spacing between dropdowns only */
        margin: 0 !important;     /* remove vertical margins */
      }

      /* Optional: keep inputs reasonable width */
      .dashboard-form .input,
      .fieldset .input {
        min-width: 260px !important;
      }
    `;
    $('head').append(`<style id="central-spacing-style">${css}</style>`);
  }

  /* ---------------------------
   * 2) Force All Table Text/Links WHITE
   * --------------------------- */
  function forceWhite() {
    $('.dashboard-body .table td, .dashboard-body .table td *')
      .css('color', '#ffffff');

    $('.dashboard-body a')
      .css({ color: '#ffffff', textDecoration: 'none' });

    try {
      document.documentElement.style.setProperty('--linkColor', '#ffffff');
    } catch (e) {}
  }

  /* ---------------------------
   * 3) Active Link Behavior
   * --------------------------- */
  function wireTableClick() {
    $('.dashboard-body')
      .off('click.activeLink')
      .on('click.activeLink', '.table a', function () {
        const $table = $(this).closest('.table');

        $table.find('a.active-link')
          .removeClass('active-link')
          .css({ color: '#ffffff', fontWeight: '' });

        $(this)
          .addClass('active-link')
          .css({ color: '#ffffff', fontWeight: '700' });
      });
  }

  /* ---------------------------
   * 4) Boot + Reapply on DOM Changes
   * --------------------------- */
  function boot() {
    injectGlobalStyles();
    forceWhite();
    wireTableClick();

    const target = document.querySelector('.dashboard-body') || document.body;
    if (target) {
      const obs = new MutationObserver(() => { forceWhite(); });
      obs.observe(target, { childList: true, subtree: true });
    }

    $(document).on('click', forceWhite);          // keep links white after clicks
    $(window).on('resize', injectGlobalStyles);   // re-inject on resize
  }

  // Initialize
  boot();

});

